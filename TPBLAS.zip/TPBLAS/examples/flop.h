
void init_flop () ;

void calcul_flop (char *message, int nb_operations_flottantes, unsigned long long int cycles) ;
